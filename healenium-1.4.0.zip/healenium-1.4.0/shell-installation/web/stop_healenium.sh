#!/bin/bash

kill $(cat ./pid-hlm-backend.file) $(cat ./pid-selector.file)